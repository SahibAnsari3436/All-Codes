<?php
/**
 * Plugin Name: Webzent Login Branding
 * Description: A plugin to change the WordPress login page logo.
 * Version: 1.0
 * Author: Shabuddin Ansari
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue custom login CSS
function webzent_login_logo() {
    echo '<style type="text/css">
        h1 a {
            background-image: url(' . plugin_dir_url(__FILE__) . 'images/webzent-logo.png) !important;
            background-size: contain !important;
            width: 100% !important;
            height: 100px !important;
        }
    </style>';
}
add_action('login_enqueue_scripts', 'webzent_login_logo');
